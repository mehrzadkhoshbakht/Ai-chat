# My Python App
A simple Python project that fetches your IP from the internet using `requests`.
