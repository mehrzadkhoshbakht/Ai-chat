import requests

res = requests.get("https://httpbin.org/ip")
print("Your IP is:", res.json()["origin"])
